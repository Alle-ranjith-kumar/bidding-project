# Bidding project containing angular and api 
